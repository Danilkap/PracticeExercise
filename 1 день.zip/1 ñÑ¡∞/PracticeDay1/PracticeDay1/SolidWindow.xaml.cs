﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PracticeDay1
{
    /// <summary>
    /// Логика взаимодействия для SolidWindow.xaml
    /// </summary>
    public partial class SolidWindow : Window
    {
        public SolidWindow()
        {
            InitializeComponent();

            button1.Background = new SolidColorBrush(Colors.Blue);
            button1.Background = new SolidColorBrush(Color.FromRgb(207, 255, 255));
        }

        private void buttonBack_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();
            main.Show();
            this.Close();
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
