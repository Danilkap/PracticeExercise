﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PracticeDay1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            SolidWindow win2 = new SolidWindow();
            win2.Show();
            this.Close();
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            LinearWindow win3 = new LinearWindow();
            win3.Show();
            this.Close();
        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
            RadialWindow win4 = new RadialWindow();
            win4.Show();
            this.Close();
        }

        private void button4_Click(object sender, RoutedEventArgs e)
        {
            ImageWindow win5 = new ImageWindow();
            win5.Show();
            this.Close();
        }
    }
}
